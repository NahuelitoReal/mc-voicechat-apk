package com.nahuel.vc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap

object Shared {
    @Volatile var status = "Desconectado"
    @Volatile var users: List<String> = emptyList()
    @Volatile var me = ""
    @Volatile var active = false
    @Volatile var manualMic = false
    val muted = ConcurrentHashMap<String, Boolean>()
    val vol = ConcurrentHashMap<String, Float>()

    fun reset() {
        status = "Desconectado"
        users = emptyList()
        active = false
        manualMic = false
    }
}

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var userIn: EditText
    private lateinit var roomIn: EditText
    private lateinit var micBtn: Button
    private var sig = ""
    private var next: (() -> Unit)? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 40, 40, 40)
        userIn = EditText(this)
        userIn.hint = "Usuario de Minecraft"
        userIn.setSingleLine()
        roomIn = EditText(this)
        roomIn.hint = "Codigo de sala (solo para unirte)"
        roomIn.setSingleLine()
        val create = Button(this)
        create.text = "Crear sala"
        val join = Button(this)
        join.text = "Unirme a la sala"
        val exit = Button(this)
        exit.text = "Salir"
        micBtn = Button(this)
        micBtn.text = "Microfono manual: apagado"
        status = TextView(this)
        status.setPadding(0, 20, 0, 20)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(userIn)
        root.addView(roomIn)
        root.addView(create)
        root.addView(join)
        root.addView(micBtn)
        root.addView(exit)
        root.addView(status)
        root.addView(list)
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
        micBtn.setOnClickListener {
            if (Shared.active) Shared.manualMic = !Shared.manualMic
            else Toast.makeText(this, "Primero crea o unite a una sala", Toast.LENGTH_SHORT).show()
        }
        create.setOnClickListener { go("") }
        join.setOnClickListener { go(roomIn.text.toString().trim()) }
        exit.setOnClickListener { stopService(Intent(this, VoiceService::class.java)) }
        tick()
    }

    private fun go(room: String) {
        val u = userIn.text.toString().trim()
        if (u.isEmpty()) {
            Toast.makeText(this, "Pone tu usuario", Toast.LENGTH_SHORT).show()
            return
        }
        if (Shared.active) {
            Toast.makeText(this, "Ya estas en una sala. Toca Salir", Toast.LENGTH_SHORT).show()
            return
        }
        val run: () -> Unit = {
            val i = Intent(this, VoiceService::class.java).putExtra("user", u).putExtra("room", room)
            startForegroundService(i)
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isEmpty()) {
            run()
        } else {
            next = run
            requestPermissions(need.toTypedArray(), 1)
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            next?.invoke()
        }
        next = null
    }

    private fun tick() {
        status.text = Shared.status
        micBtn.text = "Microfono manual: " + (if (Shared.manualMic) "encendido" else "apagado")
        val others = Shared.users.filter { it != Shared.me }
        val s = others.joinToString(",")
        if (s != sig) {
            sig = s
            list.removeAllViews()
            for (u in others) list.addView(row(u))
        }
        h.postDelayed({ tick() }, 1000)
    }

    private fun row(u: String): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        val c = CheckBox(this)
        c.text = u + " (silenciar)"
        c.isChecked = Shared.muted[u] == true
        c.setOnCheckedChangeListener { _, on -> Shared.muted[u] = on }
        val sb = SeekBar(this)
        sb.max = 100
        sb.progress = ((Shared.vol[u] ?: 1f) * 100).toInt()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                Shared.vol[u] = p / 100f
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        r.addView(c)
        r.addView(sb)
        return r
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
