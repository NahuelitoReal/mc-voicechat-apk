package com.nahuel.vc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.java_websocket.WebSocket as McSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

class VoiceService : Service() {
    private val serverUrl = "wss://mc-voicechat-server.onrender.com"
    private val main = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(90, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()
    private val waiting = ConcurrentHashMap<String, (JSONObject) -> Unit>()
    private val pos = ConcurrentHashMap<String, DoubleArray>()
    private val tracks = ConcurrentHashMap<String, AudioTrack>()
    private var mcServer: WebSocketServer? = null
    @Volatile private var mcConn: McSocket? = null
    @Volatile private var rws: WebSocket? = null
    @Volatile private var running = false
    @Volatile private var speaking = false
    @Volatile private var user = ""
    @Volatile private var roomCode = ""
    @Volatile private var srvMsg = "conectando"
    private var recognizer: SpeechRecognizer? = null

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(b: Bundle?) {}
        override fun onEvent(t: Int, b: Bundle?) {}
        override fun onError(e: Int) {
            if (speaking) main.postDelayed({ startRecognizer() }, 600)
        }
        override fun onResults(b: Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) say(t)
            if (speaking) main.postDelayed({ startRecognizer() }, 150)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (running || i == null) return START_NOT_STICKY
        user = i.getStringExtra("user") ?: ""
        val room = i.getStringExtra("room") ?: ""
        running = true
        Shared.active = true
        Shared.me = user
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vc", "Chat de voz", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "vc")
            .setContentTitle("Chat de voz activo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        startMc()
        connect(room)
        loop()
        refresh()
        return START_NOT_STICKY
    }

    private fun refresh() {
        val mc = if (mcConn != null) "conectado" else "esperando (/wsserver 127.0.0.1:8080)"
        val code = if (roomCode.isEmpty()) "-" else roomCode
        val mic = if (speaking) "activo" else "apagado"
        Shared.status = "Sala: " + code + "\nServidor: " + srvMsg + "\nMinecraft: " + mc + "\nMic: " + mic
    }

    private fun startMc() {
        val s = object : WebSocketServer(InetSocketAddress(InetAddress.getLoopbackAddress(), 8080)) {
            override fun onOpen(c: McSocket, h: ClientHandshake) {
                mcConn = c
                refresh()
            }
            override fun onClose(c: McSocket, code: Int, reason: String?, remote: Boolean) {
                if (mcConn === c) mcConn = null
                refresh()
            }
            override fun onMessage(c: McSocket, m: String) {
                handleMc(m)
            }
            override fun onError(c: McSocket?, e: Exception?) {}
            override fun onStart() {}
        }
        s.isReuseAddr = true
        s.start()
        mcServer = s
    }

    private fun handleMc(m: String) {
        try {
            val o = JSONObject(m)
            val id = o.optJSONObject("header")?.optString("requestId") ?: return
            val cb = waiting.remove(id) ?: return
            cb(o.optJSONObject("body") ?: JSONObject())
        } catch (e: Exception) {
        }
    }

    private fun cmd(line: String, cb: ((JSONObject) -> Unit)? = null) {
        val c = mcConn ?: return
        val id = UUID.randomUUID().toString()
        if (cb != null) waiting[id] = cb
        val header = JSONObject()
            .put("version", 1)
            .put("requestId", id)
            .put("messagePurpose", "commandRequest")
            .put("messageType", "commandRequest")
        val body = JSONObject()
            .put("origin", JSONObject().put("type", "player"))
            .put("commandLine", line)
            .put("version", 1)
        try {
            c.send(JSONObject().put("header", header).put("body", body).toString())
        } catch (e: Exception) {
        }
    }

    private fun loop() {
        Thread {
            while (running) {
                if (mcConn != null) {
                    cmd("testfor @a[name=\"$user\",tag=vc_mic]") { b ->
                        setMic(b.optInt("statusCode", -1) == 0)
                    }
                    for (u in Shared.users) {
                        cmd("querytarget @a[name=\"$u\"]") { b -> parsePos(u, b) }
                    }
                }
                try {
                    Thread.sleep(400)
                } catch (e: Exception) {
                }
            }
        }.start()
    }

    private fun parsePos(u: String, b: JSONObject) {
        try {
            val o = JSONArray(b.optString("details")).getJSONObject(0)
            val p = o.getJSONObject("position")
            pos[u] = doubleArrayOf(p.getDouble("x"), p.getDouble("y"), p.getDouble("z"), o.optDouble("dimension", 0.0))
        } catch (e: Exception) {
        }
    }

    @Synchronized
    private fun setMic(on: Boolean) {
        if (on && !speaking) {
            speaking = true
            refresh()
            Thread { record() }.start()
            main.post { startRecognizer() }
        } else if (!on && speaking) {
            speaking = false
            refresh()
            main.post { recognizer?.stopListening() }
        }
    }

    private fun record() {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                rate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(min, 6400)
            )
        } catch (e: Exception) {
            speaking = false
            return
        }
        val buf = ByteArray(3200)
        try {
            rec.startRecording()
            while (speaking) {
                var n = 0
                while (n < buf.size && speaking) {
                    val r = rec.read(buf, n, buf.size - n)
                    if (r <= 0) break
                    n += r
                }
                if (n > 0) {
                    val d = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                    rws?.send(JSONObject().put("t", "a").put("d", d).toString())
                } else {
                    Thread.sleep(20)
                }
            }
        } catch (e: Exception) {
        } finally {
            try {
                rec.stop()
            } catch (e: Exception) {
            }
            rec.release()
        }
    }

    private fun startRecognizer() {
        if (!speaking || !SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        r.startListening(i)
    }

    private fun say(text: String) {
        val t = "<vc-" + user + ">: " + text
        val raw = JSONObject().put("rawtext", JSONArray().put(JSONObject().put("text", t))).toString()
        cmd("tellraw @a " + raw)
    }

    private fun connect(room: String) {
        val req = Request.Builder().url(serverUrl).build()
        rws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val o = JSONObject().put("t", if (room.isEmpty()) "create" else "join").put("user", user)
                if (room.isNotEmpty()) o.put("room", room)
                webSocket.send(o.toString())
                srvMsg = "conectado"
                refresh()
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                onServer(text)
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                srvMsg = "no se pudo conectar"
                refresh()
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                srvMsg = "desconectado"
                refresh()
            }
        })
    }

    private fun onServer(text: String) {
        try {
            val o = JSONObject(text)
            when (o.optString("t")) {
                "joined" -> {
                    roomCode = o.optString("room")
                    setUsers(o.optJSONArray("users"))
                }
                "joined_other", "left" -> setUsers(o.optJSONArray("users"))
                "error" -> srvMsg = "error: " + o.optString("m")
                "a" -> play(o.optString("from"), o.optString("d"))
            }
            refresh()
        } catch (e: Exception) {
        }
    }

    private fun setUsers(a: JSONArray?) {
        val l = ArrayList<String>()
        if (a != null) {
            for (i in 0 until a.length()) l.add(a.getString(i))
        }
        Shared.users = l
    }

    private fun gain(from: String): Float {
        val a = pos[user]
        val b = pos[from]
        if (a == null || b == null) return 1f
        if (a[3] != b[3]) return 0f
        val dx = a[0] - b[0]
        val dy = a[1] - b[1]
        val dz = a[2] - b[2]
        val dist = sqrt(dx * dx + dy * dy + dz * dz)
        return (1.0 - dist / 32.0).coerceIn(0.0, 1.0).toFloat()
    }

    private fun newTrack(): AudioTrack {
        val min = AudioTrack.getMinBufferSize(16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(16000)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(min, 16000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.play()
        return t
    }

    private fun play(from: String, d: String) {
        if (from.isEmpty() || Shared.muted[from] == true) return
        val g = gain(from) * (Shared.vol[from] ?: 1f)
        if (g < 0.02f) return
        val raw = Base64.decode(d, Base64.NO_WRAP)
        val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val s = ShortArray(bb.remaining())
        bb.get(s)
        for (i in s.indices) {
            s[i] = (s[i] * g).toInt().coerceIn(-32768, 32767).toShort()
        }
        val t = tracks.getOrPut(from) { newTrack() }
        t.write(s, 0, s.size)
    }

    override fun onDestroy() {
        running = false
        speaking = false
        try {
            rws?.close(1000, null)
        } catch (e: Exception) {
        }
        try {
            mcServer?.stop(0)
        } catch (e: Exception) {
        }
        recognizer?.destroy()
        for (t in tracks.values) {
            try {
                t.stop()
                t.release()
            } catch (e: Exception) {
            }
        }
        tracks.clear()
        Shared.reset()
        super.onDestroy()
    }
}
